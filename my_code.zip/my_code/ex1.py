#python3
import random 

mode="recursive_changee"

n=10
money = random.randint(1,10)
#money=8
coins=[1,2,5]


def recursive_change_fun(money, coins=coins,count=0):
	if money==0:
		return 0

	min_no_of_coins=money

	for i in coins:
		if money>=i:
			no_of_coins = recursive_change_fun(money-i)

		if min_no_of_coins > no_of_coins +1:

			min_no_of_coins = no_of_coins +1

	return min_no_of_coins

def dpchange_fun(money,coins=0):
	min_no_of_coins=[]
	min_no_of_coins.append(0) 
	for i in range(0,len(money)):
		min_no_of_coins[i].append(m)





#recursive change 
if mode=="recursive_change":
	print("recursive change mode ")
	print("money to change = ", money)
	print("available coins = ", end=" " )
	[print(i, end=", ") for i in coins]
	print("")
	print("-------------------------------")

	x = recursive_change_fun(money,coins)
	print(" ")
	print(x)


if mode=="dynammic_change":
	print("dynammic change mode ")
	print("money to change = ", money)
	print("available coins = ",  end=" ", )
	[print(i, end=", ") for i in coins]
	print("")
	print("-------------------------------")

	x = dpchange(money,coins)
	print(" ")
	print(x)


