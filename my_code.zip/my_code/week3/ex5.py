#python3

n=int(input())


k=n
j=1
z=[]
while 2*j<k:
	z.append(j)
	k=k-j
	j=j+1

z.append(k)
print(len(z))
print(*z, sep=' ')