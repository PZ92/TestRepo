#python3

if True:
	items_no,W=input().split()
	items_no=int(items_no)
	W=int(W)
	data=[]

	i=0
	while i!=items_no:
		i=i+1
		data.append([int(k) for k in input().split()])

	
else:
	items_no=3
	W=50
	data=[[100,50],[120, 30],[60,20]]

money=0
sorted_data=sorted(data,key=lambda x: x[0]/x[1],reverse=True)
#print(sorted_data)

while W!=0 and sorted_data!=[]:
	v=sorted_data[0][0]
	w=sorted_data[0][1]
	
	#print(w,v,W,sorted_data)
	if w<W:
		W=W-w
		money=money+v
		sorted_data.pop(0)
	else:
		money=money+W/w*v
		W=0


print(money)