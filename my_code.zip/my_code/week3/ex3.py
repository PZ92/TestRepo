#python3

n=int(input()) # integer
a=input().split() # profits per click 1 to n
b=input().split() # expected clicks on slot 1 to n 

profit=sorted([int(i) for i in a], reverse=True)
clicks=sorted([int(i) for i in b], reverse = True)

#this way because we want a greedy algorithm :x
i=0
revenue=0
#print(profit)
#print(clicks)
while i!=n:
	p=profit[0]
	c=clicks[0]
	revenue=revenue+p*c
	profit.pop(0)
	clicks.pop(0)
	i=i+1

print(revenue)

