#python3
if True:
	n=int(input())
	a=[]
	inp=input().split()
	a=[i for i in inp]
else:
	n=2
	a2=['21','2']
	n=5
	a=['40','9','4','410']
	#a=['21','2']
	#a=['9','4','6','1','9']
	#a=['23','39','92']
#no of numbers
# a - my numbers


a=sorted(a)
a_memo=a.copy()
a_lens=[]
for i in range(0,len(a)):
	a_lens.append(len(a[i]))

max_len=max(a_lens)+1
c=[]
for i in range(0,len(a)):
	#print(a[i],' ',max_len-len(a[i]))
	n1=a[i]+a[i]*(max_len-len(a[i]))
	n2=a_lens[i]
	c.append([n1[:max_len],n2])

#print(c)


#print(a_memo)

c=sorted(c,key=lambda x: x[0],reverse=True)
#print(c)
x=''
for i in range(0,len(c)):
	num=c[i][0]
	l=c[i][1]
	num=num[0:l]
	x=x+num
print(int(x))
