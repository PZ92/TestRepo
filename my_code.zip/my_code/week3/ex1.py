#python3

m=int(input())

dens=[1,5,10]


coins=0
while m!=0:
#	print(dens,m,coins)
	z=m//max(dens)

	m=m-z*max(dens)
	dens.remove(max(dens))
	coins=coins+z


print(coins)