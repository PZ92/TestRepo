A=[7,9,3,0,7]
B=[12,14,8,5,12]

means=[(A[i]+B[i])/2 for i in range(0,len(A))]
print(means)
a=[]
b=[]
for i in range(0,len(means)):
	index=means.index(max(means))
	a.append(A[index])
	b.append(B[index])
	means[index]=min(means)-1

print(A)
print(B)

print(a)
print(b)
means2=[(a[i]+b[i])/2 for i in range(0,len(a))]
print(means2)