#python3

if False:
	n=int(input())
	data_input=input().split()
	data=[int(i) for i in data_input]
else:
	n=7
	data=[7,6,3,8,2,1,3]



def partition(arr,l,r):

	i=l-1# i=-1
	pivot=arr[r]#pivot - ostatni element
	print("->i= ",i,"  j= ","-","  ar= ",arr[l:r],"  pi= ",pivot," | ",arr)
	print("___________________________________________________________________________")
	j=0
	for j in range(l,r):
		
		if arr[j]<=pivot: #jezeli a[0] < a[r]
			i=i+1# i=0
			arr[i],arr[j]=arr[j],arr[i]# a[0]=a[1], a[1]=a[0]
			print("-i= ",i,"  j= ",j,"  ar= ",arr[l:r],"  pi= ",pivot," | ",arr)
		else:
			print("+i= ",i,"  j= ",j,"  ar= ",arr[l:r],"  pi= ",pivot," | ",arr)
		

	arr[i+1],arr[r]=arr[r],arr[i+1]
	print("")
	print("i= ",i,"  j= ",j,"  ar= ",arr[l:r],"  pi= ",pivot," | ",arr)
	return i+1

def qs(arr,l,r):

	if l<r:
		pi=partition(arr,l,r)
		qs(arr,l,pi-1)
		#qs(arr,pi-1,pi+1)
		qs(arr,pi+1,r)



qs(data,0,len(data)-1)