#python3 
def ms(alist,x):
	x=x+15
	print("_"*x,alist)
	if len(alist)>1:
		mid = len(alist)//2
		l=alist[:mid]
		r=alist[mid:]

		ms(l,x)
		ms(r,x)

		i,j,k=0,0,0

		while i<len(l) and j<len(r):
			if l[i]<r[i]:
				alist[k]=l[i]
				i=i+1
			else:
				alist[k]=r[j]
				j=j+1
			k=k+1

		while i<len(l):
			alist[k]=l[i]
			i+=1
			k+=1
		while j<len(r):
			alist[k]=r[j]
			j+=1
			k+=1
	
		print("_"*x,"->",alist)
	else:
		print("_"*x,".")

alist=[54,26,93,17,77,31,44,55,20,21]
ms(alist,0)
print(alist)