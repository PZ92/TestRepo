import java.util.Scanner;
import java.util.ArrayList;
import java.lang.Math;

public class ex1_slow{
	long[] data;// ={1,5,8,12,13};
	long[] keys;//={8,1,23,1,11};



	//long[] data ={1,2,3,4,5};//{1,5,8,12,13};
	//long[] keys={1,2,3,4,5};//{8,1,23,1,11};


	int n; // no of elements in binary search array
	int k; // no of keys to find
	Scanner sc = new Scanner(System.in); 

	public ex1_slow()
	{
		//this.n = get_integer();
		this.data =get_array();
		//this.k=get_integer();
		this.keys=get_array();

	//this.data=data;
	//this.keys=keys;

	}

	public long[] get_array()
	{
		//System.out.println("input sequence...");
		int n = sc.nextInt();
		long[] numbers = new long[n];
		for (int i = 0; i < numbers.length; i++)
    	{
        	numbers[i] = sc.nextLong();
    	}
		return numbers;
	}


///////////// some methods 

	public long binary_search(long [] data, long key, long start)
	{
		long left=start;
		long right =data.length-1;
		
	//	System.out.println("-index = " + index);
//		System.out.println("-val = " + val);
//		System.out.println("-key = " + key);
		long index=-1;
		long m=0;
		
		while ((left<=right) ) //data[m]!=key)
		{
			//m = (long)Math.floor((left+right)/2);
			m= (long) (left + (right-left)/2);
			//m = (int)((left+right)/2.0 - 0.5);
//			System.out.println("left= " + left);
//			System.out.println("right= " + right);
//			System.out.println("m= " + m);
//			System.out.println("data[m]= " + data[m]);
//			System.out.println("key= " + key);
//			System.out.println("---------");
		//m-1 = data_m>key ? right : right;
		
		long data_m = data[(int)m];
		if (data_m<key)
			{
				left=m+1;
			}
		else if (data_m>key)
			{
				right=m-1;
			}
		
		else 
			{
			index = m;
			return index;
			}
			
		}

		return -1;

	//	System.out.println("------------------");
	//	System.out.println("index = " + index);
	//	System.out.println("val = " + val);
	//	System.out.println("key = " + key);
	}

	public static void main(String[] args) 
	{

		ex1_slow ex = new ex1_slow();

		long[] data = ex.data;
		long [] keys = ex.keys;
		//System.out.print("asd");
		long old_key = 0 ;
		long start=0;
		long index=0;
		//ex.binary_search(data,keys[0]);
		long key=0;
		int j=0;
		while (j!=keys.length){
			key=keys[j];
		
//		for(int key : keys){
			//if (key > old_key){start = index;}
			//if (key>old_key){start=index; end=data.length-1;}
			//else if (key<old_key){start=0; end=index+1;}
			//else{start=0; end=data.length-1;}
			index = ex.binary_search(data,key,0);


			
			//System.out.print(ex.binary_search(data,key,start)+ " ");
			System.out.print(index+ " ");
			old_key=key;
			start=0;
			j=j+1;
		}

	}
	
} 