#python3

data_input=input().split()
keys_input=input().split()

data=[int(i) for i in data_input]
keys= [int(i) for i in keys_input]
n=data.pop(0);
k=keys.pop(0);

#print(data)
#print(keys)
#print("n=",n)
#print(k)

#{1,5,8,12,13};
#{8,1,23,1,11}

def bsearch(k,data,n):
    l=0
    r=n-1


    while l<=r:

        m=l+(r-l)//2
        d=data[m]

        if(d<k):
            l=m+1
        elif (d>k):
            r=m-1
        else:
            return str(m) 

    return "-1"

ans=[]
for i in range(0,k):
    ans.append(bsearch(keys[i],data,n))
    
print(" ".join(ans))

