#python3

def merge(arr,l,m,r):
	#print("------",l,m,r)
	n1=m-l+1# len of first arr
	n2=r-(m+1)+1#len of second arr
	
	L=[0]*n1
	R=[0]*n2

	for i in range(0,n1):
		L[i]=arr[l+i]

	for j in range(0,n2):
		R[j]=arr[m+1+j]
	i=0
	j=0
	k=l
	while i<n1 and j<n2:
		if L[i]<=R[j]:
			arr[k]=L[i]
			i+=1
		else:
			arr[k]=R[j]
			j+=1
		k+=1
	while i<n1:
		arr[k]=L[i]
		i+=1
		k+=1
	while j<n2:
		arr[k]=R[j]
		j+=1
		k+=1

	print(arr)



def ms(arr,l,r,x,x2):
	x=x+1
	print("->",l,round((l+(r-1))/2,0),r," __" ,x,x2)
	#r - rightmost index
	#l - leftmost index 
	if l<r:
		
		m = (l+(r-1))/2
		m=int(round(m,0))
		
		ms(arr,l,m,x,"L")
		ms(arr,m+1,r,x,"R")
		merge(arr,l,m,r)
	else:
		print("ok")


data=[1,9,7,6,8,5,2,4]
data=data[::-1]
l=0
r=len(data)-1
ms(data,l,r,0,"O")