#python3
import random
if 0:
	n=int(input())
	data=[int(i) for i in input().split()]
	
	#data=[int(i) for i in data_input]
else:
	n=5
	data=[2,3,9,2,9,5,4,2,1,2,3,5,6,7,8,1]
	data=[2,3,9,2,2]
	data = [7,6,8,2,3,1,3]



def partition(A,l,r):
	#print(A,A[l:r])
	pivot = A[r]
	i=l-1
	k=0
	z=1
	b=True
	j=l
	while j<r:
		print("  ",A,A[j],j)
		if A[j]<=pivot:
	#		print("                            ",A,A[i],A[j])
			i=i+1
			A[i],A[j]=A[j],A[i]
		j=j+1
	
	A[i+1],A[r]=A[r],A[i+1]
	
	print("->",A,i+1,j,k)
	return i+1,k

def partition3(a, l, r):
	x, j, t = a[l], l, r
	i = j

	while i <= t:
		print(a)
		if a[i] < x:
			a[j], a[i] = a[i], a[j]
			j += 1

		elif a[i] > x:
			a[t], a[i] = a[i], a[t]
			t -= 1
			i -= 1 # remain in the same i in this case
		i += 1   
	print("->",a)
	return j, t

def qs(A,l,r):
	if l<r:
		k = random.randint(l,r)
		A[k],A[l]=A[l],A[k]
		m1,m2=partition3(A,l,r)
		#print(A,"l= ",l,"m= ",m,"z= ",zz)
		#m2=partition2(A,l,r)
		qs(A,l,m1-1)
		qs(A,m2+1,r)

	return A


S=qs(data,0,len(data)-1)
x=[str(i) for i in S]
print(" ".join(x))
