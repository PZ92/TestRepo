#python3
#majority element with moore's voting algorithm
n=int(input())
data_input=input().split()

#n=int(data_input.pop(0))
data=[int(i) for i in data_input]



def moore_algorithm(n,data):
	#initialize majority index and its count
	majority_index=0
	count=1
	i=1
	while i!=n:
		#print("i=",i)
		#print("m= ",majority_index)
		#print("c= ",count)

		if data[majority_index]==data[i]:
			#print("1")
			count=count+1
		else:
			#print("2")
			count=count-1

		if count ==0:
			#print("3")
			majority_index=i
			count=1
		i=i+1
		#print("------------------")
	#print(majority_index)
	#print(data[majority_index])
	#print(data.count(data[majority_index]))

	if data.count(data[majority_index])>n/2:
		return 1#data[majority_index]
	else:
		return 0

ans=moore_algorithm(n,data)

print(ans)
#print("l=",len(data))



#print(moore_algorithm(n,data))