#python3

#Problem Description
#Task. Given an integer n, find the nth Fibonacci number F n .
#Input Format. The input consists of a single integer n.
#Constraints. 0 ≤ n ≤ 45.
#Output Format. Output F n .
#Input:
#10
#Output:
#55
#F10 = 55.


#n=10

def Fibonacci(n):
	fib=[0,1]

	if n <=1:
		return n
	else:
		while len(fib)!=n+1:
			fib.append(fib[-1]+fib[-2])
	
		return(fib[-1])

n=int(input())
print(Fibonacci(n))