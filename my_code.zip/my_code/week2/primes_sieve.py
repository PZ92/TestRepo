primes=[0,2,3,5,7,11,13,17,19,23,29,31,37,41,43]

def isprime(n):
    """Returns True if n is prime."""
    if n == 2:
        return True
    if n == 3:
        return True
    if n % 2 == 0:
        return False
    if n % 3 == 0:
        return False

    i = 5
    w = 2

    while i * i <= n:
        if n % i == 0:
            return False

        i += w
        w = 6 - w

    return True

n=50

def sieve(n):
	l=list(range(2,n+1))# 0 -> 29
	l2=list(range(2,n+1))# 0 -> 29
	x1=0
	x2=1
	j=0
	while x1!=x2:
		x1=len(l2)
		step=l2[j]
		lx=[]
		max_index=len(l)
		i=step-2
		
		while i<max_index-step:
			i=i+step
			try:
				l2.remove(l[i])
			except:
				pass
			#print(i,len(l))
			#lx.append(l[i])
	
		#[l2.remove(x) for x in lx if x in l2]

		x2=len(l2)
		j=j+1

	return l2


def find_divisors(primes,sieve_no,n):
	import time
	start_time=time.time()
	print("finding divisors..")
	divisors=[]
	i=0
	g=0
	while n!=1:
		#print(i,len(primes),primes[i],i == len(primes)-1,sieve_no)
		if n%primes[i] == 0:
			divisors.append(primes[i])
			n=n/primes[i]
			i=-1
		i=i+1
		if i == len(primes)-1 and not isprime(n):
			print("------")
			print(n,i)
			sieve_no=sieve_no*2
			primes=sieve(sieve_no)
			#print("sieeeve")
			#print(len(primes))
		if isprime(n):
			print("isprime!")
			divisors.append(n)
			n=1
		
	print("divisors found in= ",start_time-time.time())
	return divisors,primes


sieve_no=100
primes=sieve(sieve_no)

import random
j=0
while j<10000:
	n=random.randint(1,10**9)
	print(find_divisors(primes,sieve_no,n))
	j=j+1

print(j)
#-------------------------------------------

#-------------------------------------------
