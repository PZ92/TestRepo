#python3

inp=input().split()
n=int(inp[0])
mod=int(inp[1])#period=mod+1?
def pisano(n,mod):
	m0=0
	m1=1
	j=1
	j2=-1
	g=0
	rems=[0]
	#print(F%mod)
	while (j,j2)!=(0,1):
		g=g+1
		#print(g,Fibonacci(g)%mod,j,j2)
		rems.append(j)
		j=(m0+m1)%mod
		m0=m1
		m1=j
		j2=(m0+m1)%mod
		
		

	#print(rems)
	#print('------')
	return rems[n%len(rems)]


print(pisano(n,mod))






