#python3

def gcd(a,b):
	while a%b !=0:
		a_old=a
		b_old=b 

		a=b_old 
		b=a_old%b_old
	return b 




a=input().split()
b=int(a[1])
a=int(a[0])

print(gcd(a,b))