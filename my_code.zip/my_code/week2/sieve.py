#python3


def sieve(n):
	#returns list of primes up to n 
	#works fine for n ~= 10**5
	l=list(range(2,int(n+1)))# 0 -> 29
	l2=list(range(2,int(n+1)))# 0 -> 29
	x1=0
	x2=1
	j=0
	max_index=len(l)
	while x1!=x2:
		x1=len(l2)
		step=l2[j]
		i=step-2
		while i<max_index-step:
			i=i+step
			if l[i] in l2:
				l2.remove(l[i])
				x2=len(l2)
		j=j+1
	return l2

def isprime(n):
	#returns true if n is prime    
    if n == 2:
        return True
    if n == 3:
        return True
    if n % 2 == 0:
        return False
    if n % 3 == 0:
        return False

    i = 5
    w = 2

    while i * i <= n:
        if n % i == 0:
            return False

        i += w
        w = 6 - w

    return True


import time
start=time.time()
sieve(2*10**4)
print(time.time()-start)