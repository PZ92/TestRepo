#python3
#inp=input().split()
#n1=int(inp[0])
#n2=int(inp[1])

def isprime(n):
    """Returns True if n is prime."""
    if n == 2:
        return True
    if n == 3:
        return True
    if n % 2 == 0:
        return False
    if n % 3 == 0:
        return False

    i = 5
    w = 2

    while i * i <= n:
        if n % i == 0:
            return False

        i += w
        w = 6 - w

    return True


def sieve(n):
	l=list(range(2,n+1))# 0 -> 29
	l2=list(range(2,n+1))# 0 -> 29
	x1=0
	x2=1
	j=0
	while x1!=x2:
		x1=len(l2)
		step=l2[j]
		lx=[]
		max_index=len(l)
		i=step-2
		while i<max_index-step:
			i=i+step
			try:
				l2.remove(l[i])
			except:
				pass

		x2=len(l2)
		j=j+1
	return l2


def find_divisors(primes,sieve_no,n):
	divisors=[]
	i=0
	g=0
	k=2
	while n!=1:
		
		#print(i,primes[i],n,isprime(n))
		if n%primes[i] == 0:
			#print("xd")
			divisors.append(primes[i])
			n=n/primes[i]
			i=-1
		i=i+1
		if isprime(n):
			divisors.append(n)
			#print("yay")
			n=1
			#print("yay")
			return divisors
		if i == len(primes)-1:
			#print("asshl")
			#print(len(primes))
			new_primes=sieve(sieve_no*k)
			while len(new_primes)==len(primes):
					k=k+3
					print("------")
					new_primes=sieve(sieve_no*k)
			#sieve_no=sieve_no*10 # might not work if there are no primes between sieve_no and 3*sieve_no
			
			primes=new_primes
			
	
	return divisors



#-------------------------------------------

#-------------------------------------------

def find_lcm(n1,n2):
	
	#n1=5*4*7*8*56*4*7*8*51*15*1
	#n2=2*4*5*6*8*7*58*42*1*4*7*856*0+1
	sieve_no=int(10**4)
	primes=sieve(sieve_no)
	n1_divisors=find_divisors(primes,sieve_no,n1)
	
	n2_divisors=find_divisors(primes,sieve_no,n2)


	if len(n1_divisors)<len(n2_divisors):
		short_divisors_list=n1_divisors
		long_divisors_list=n2_divisors
	else:
		short_divisors_list=n2_divisors
		long_divisors_list=n1_divisors

	if len(n1_divisors)<len(n2_divisors):
		short_divisors_list=n1_divisors
		long_divisors_list=n2_divisors
	else:
		short_divisors_list=n2_divisors
		long_divisors_list=n1_divisors


	short_divisors_set=list(set(short_divisors_list))
	long_divisors_set=list(set(long_divisors_list))
	n3_divisors=[]

	for i in short_divisors_set:
		if short_divisors_list.count(i) >= long_divisors_list.count(i):
			power=short_divisors_list.count(i)
		else:
			power=long_divisors_list.count(i)
		n3_divisors.append(i**power)

	for i in long_divisors_set:
		if i not in short_divisors_set:
			power=long_divisors_list.count(i)

			n3_divisors.append(i**power)


	n3=1
	for i in n3_divisors:
		n3=int(n3)*int(i)


	return int(n3) 

inp=input().split()
n1=int(inp[0])
n2=int(inp[1])
print(find_lcm(n1,n2))
#soooooooooooooooooooooooooooo UGLYYYYYYYYYYYY :((((( 

#import random
#import time 
#j=0

#while j<100:
#	start_time=time.time()
#	x1=random.randint(10**8,10**9)
#	x2=random.randint(10**8,10**9)

#	print("x1=",x1)
#	print("x2=",x2)
#	print(isprime(x1))
#	print(isprime(x2))
#	print(find_lcm(x1,x2))
#	print("   time=   ",round(time.time()-start_time,2))

#	j=j+1

#x1=405115803
#x2=621060682
#x1=2000000000
#x2=1999999994

#print(find_divisors(sieve(1000),1000,x1))
#print('----')
#print(find_divisors(sieve(1000),1000,x2))
#print(find_lcm(x1,x2))