case=2
#naive
if case==1:
	#a=input()
	#b=input()
	a=10
	b=4
	best=0
	for i in range(1,a+b):
		print(a%i, b%i, i)
		if a%i==0 and  b%i==0:
			best=i
	#print(best)

#euclid alg
if case==2:
	a=357
	b=234
	if b==0:
		print(a)
		#return a
	else:
		while a%b!=0:
			old_a=a
			old_b=b

			a=old_b
			b=old_a%old_b 

		#return b 
		print(b)

243561
3746281