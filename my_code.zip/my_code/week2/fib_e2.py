#python3
#Your goal in this problem is to find the last digit of n-th Fibonacci number. Recall that Fibonacci numbers
#grow exponentially fast. For example,

def Fibonacci(n):
	fib=[0,1,1]
	j=0
	if n <=1:
		x=str(n)
	else:
		while j!=n:
			fib[0]=int(str(fib[1])[-1])#gotta store last digit of number
			fib[1]=int(str(fib[2])[-1])#because big numbers add up sloooooooow 
			fib[2]=int(str(fib[0]+fib[1])[-1])
			j=j+1
	
		x=str(fib[0])
	
	#print(fib)
	#print(x)
	#print(int(x[-1]))
	return int(x[-1])

n=int(input())
print(Fibonacci(n))