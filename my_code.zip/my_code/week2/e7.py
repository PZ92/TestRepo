#python3
def Fibonacci(n):
	fib=[0,1,1]
	j=0
	if n <=1:
		x=str(n)
	else:
		while j!=n:
			fib[0]=int(str(fib[1])[-1])#gotta store last digit of number
			fib[1]=int(str(fib[2])[-1])#because big numbers add up sloooooooow 
			fib[2]=int(str(fib[0]+fib[1])[-1])
			j=j+1
	
		#x=fib[0]
		x2=fib[2]
		x3=1
		x=str(x2-x3)
	return int(x[-1])

#n=int(input())
def Fib(n):
	fib=[0,1]

	if n <=1:
		return n
	else:
		while len(fib)!=n+1:
			fib.append(fib[-1]+fib[-2])
	
		#return(fib[-1])

	return fib[-1]




#inp=input().split()
#n=int(inp[0])
#mod=int(inp[1])#period=mod+1?
def pisano(n,mod=10):
	n=n+2
	m0=0
	m1=1
	j=1
	j2=-1
	g=0
	rems=[0]
	#print(F%mod)
	while (j,j2)!=(0,1):
		g=g+1
		#print(g,Fibonacci(g)%mod,j,j2)
		rems.append(j)
		j=(m0+m1)%mod
		m0=m1
		m1=j
		j2=(m0+m1)%mod
		
		

	#print(rems)
	#print('------')
	x=rems[n%len(rems)]
	x=x-1
	if x==-1:
		x=9
	return x


inp=input().split()
x1=int(inp[0])
x2=int(inp[1])
n=min(x1,x2)-1
m=max(x1,x2)
#n=11
#m=10
#n=10
#m=200

s1=pisano(max(n,m))
s2=pisano(min(n,m))

l=s1-s2
if l<0:
	l=10+s1-s2



#print(s1,s2,l)
print(l)

