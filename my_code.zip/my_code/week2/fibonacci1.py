#computing fibonacci numbers algorithms 
case=2
#naive algorithm T(n) = F(n)
if case==1:
	def fib(n):
		if n<=1:
			return n 
		else:
			return(fib(n-1)+fib(n-2))


	for i in range(0,10):
		print(fib(i))


if case ==2:
	l=[0,1]

	for i in range(2,100):
		l.append(l[-1]+l[-2])
	print(l)